# Kashta-Kala App

Digital carpenter design catalog app.

## Features
- Design catalog UI
- Material calculator
- Quote concept system

## Tech
- Kotlin (Android)
- XML UI
